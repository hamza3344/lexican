﻿using System;
using System.IO;
using System.Linq;

namespace lexican
{
    class Program
    {
        static void Main(string[] args)
        {
            string messagetotest = @"The year is 2022, and I can see murder happening on screen as easily as I can see Tom and Jerry. There was news today of a man raping and killing a goat, and the movie thinks it can shock us with murders, infidelity and Ana de Armas' feet and exposed back from a thousand different angles as she seduces a new man while Ben Affleck watches them with a blankly menacing expression on his face?
If Gone Girl were a human being, than Deep Water would be the grime under its toenails. The only thing that could have redeemed this Lifetime thriller grade plot was if it had explored the workings of the minds of these two deeply unlikeable characters, and what makes them kill and cheat and serve wine to their ten year old daughter, but the movie is not interested in that. If it wants us to do all the think work then it did a terrible job because all I saw was rich people partying, screwing and dying.";
            string[] positives = File.ReadAllLines("positive-words.txt");
            string[] negatives = File.ReadAllLines("negative-words.txt");
            double positive = 0;
            double negative = 0;
            foreach(string s in messagetotest.Split(" "))
            {
                if(positives.Any(e=>e.Equals(s.ToLower())))
                {
                    positive = positive + 1;
                }else if (negatives.Any(e => e.Equals(s.ToLower())))
                {
                    negative = negative + 1;
                }
            }
            double score = (positive - negative) / (positive + negative);
            Console.WriteLine(score);
            Console.Read();
        }
    }
}
